# Social Media Analytics API

A Node.js Express API that provides analytics for social media posts and user engagement metrics.

## Features

- Get top 5 users by comment count
- Get latest or most popular posts
- Health check endpoint
- Caching mechanism for improved performance

## Prerequisites

- Node.js (v14 or higher)
- npm (Node Package Manager)

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```

The server will start on port 3000 by default. You can change this by setting the `PORT` environment variable.

## API Endpoints

### Health Check
- `GET /health` - Check API health status

### Users
- `GET /users` - Get top 5 users by comment count

### Posts
- `GET /posts` - Get posts (latest or popular)
  - Query params:
    - `type`: 'latest' (default) or 'popular'

For detailed API documentation and testing instructions, please refer to [TESTING.md](TESTING.md)

## Error Handling

The API implements proper error handling with appropriate HTTP status codes:
- 200: Success
- 400: Bad Request
- 404: Not Found
- 500: Internal Server Error
- 502: Upstream Server Error

## Caching

The API implements a caching mechanism with a 60-second TTL (Time To Live) to optimize performance and reduce load on the upstream server.

## License

MIT
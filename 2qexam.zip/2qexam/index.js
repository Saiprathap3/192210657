const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
const TEST_SERVER = 'http://20.244.56.144/api/evaluation-service';

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/users', async (req, res) => {
    try {
        await updateAnalytics();
        const topUsers = Array.from(usersCache.entries())
            .map(([userId, data]) => ({
                userId,
                name: data.name,
                commentCount: data.commentCount
            }))
            .sort((a, b) => b.commentCount - a.commentCount)
            .slice(0, 5);

        if (!topUsers.length) {
            return res.status(404).json({ error: 'No user data available' });
        }

        res.json({ users: topUsers });
    } catch (error) {
        console.error(error);
        const status = error.message.includes('HTTP error') ? 502 : 500;
        res.status(status).json({ error: status === 502 ? 'Upstream server error' : 'Internal server error' });
    }
});

app.get('/posts', async (req, res) => {
    try {
        const type = req.query.type || 'latest';
        await updateAnalytics();

        let allPosts = [];
        for (const userData of usersCache.values()) {
            allPosts = allPosts.concat(userData.posts.map(post => ({
                ...post,
                commentCount: post.comments?.length || 0
            })));
        }

        if (!allPosts.length) return res.status(404).json({ error: 'No posts available' });

        allPosts.sort((a, b) => type === 'latest' 
            ? new Date(b.timestamp) - new Date(a.timestamp)
            : b.commentCount - a.commentCount
        );

        res.json({ posts: allPosts.slice(0, 10) });
    } catch (error) {
        console.error(error);
        const status = error.message.includes('HTTP error') ? 502 : 500;
        res.status(status).json({ error: status === 502 ? 'Upstream server error' : 'Internal server error' });
    }
});

app.all('*', (req, res) => {
    res.status(404).json({
        error: `Cannot ${req.method} ${req.path}`,
        availableEndpoints: ['/users', '/posts', '/health']
    });
});

let usersCache = new Map();
let postsCache = new Map();
let lastFetchTime = 0;
const CACHE_TTL = 60000;

async function fetchUsers() {
    const response = await fetch(`${TEST_SERVER}/users`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    if (!data?.users) throw new Error('Invalid users data');
    
    return data.users;
}

async function fetchUserPosts(userId) {
    if (!userId) throw new Error('User ID is required');
    
    const response = await fetch(`${TEST_SERVER}/users/${userId}/posts`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    if (!data?.posts?.length) throw new Error('Invalid posts data');
    
    return data.posts;
}

async function updateAnalytics() {
    try {
        const currentTime = Date.now();
        if (currentTime - lastFetchTime < CACHE_TTL) return;

        const users = await fetchUsers();
        if (!users) throw new Error('Invalid users data');

        const userCommentCounts = new Map();

        for (const [userId, userName] of Object.entries(users)) {
            try {
                const posts = await fetchUserPosts(userId);
                const totalComments = posts.reduce((sum, post) => sum + (post.comments?.length || 0), 0);
                userCommentCounts.set(userId, { name: userName, commentCount: totalComments, posts });
            } catch (err) {
                console.error(err);
                continue;
            }
        }

        if (!userCommentCounts.size) throw new Error('No user data available');

        usersCache = userCommentCounts;
        postsCache = new Map();
        const allPosts = [];

        userCommentCounts.forEach(({ posts }) => {
            if (!Array.isArray(posts)) return;
            posts.forEach(post => {
                if (!post) return;
                allPosts.push({
                    ...post,
                    commentCount: post.comments?.length || 0
                });
            });
        });

        const sortedByComments = [...allPosts].sort((a, b) => b.commentCount - a.commentCount);
        const sortedByTime = [...allPosts].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        postsCache.set('popular', sortedByComments);
        postsCache.set('latest', sortedByTime);
        lastFetchTime = currentTime;
    } catch (error) {
        console.error(error);
        throw error;
    }
}

// API Routes
app.get('/users', async (req, res) => {
    try {
        await updateAnalytics();
        if (usersCache.size === 0) {
            return res.status(404).json({ error: 'No user data available' });
        }

        const topUsers = [...usersCache.entries()]
            .sort((a, b) => b[1].commentCount - a[1].commentCount)
            .slice(0, 5)
            .map(([userId, data]) => ({
                userId,
                name: data.name,
                commentCount: data.commentCount
            }));

        res.json({ users: topUsers });
    } catch (error) {
        console.error('Error in /users endpoint:', error);
        const statusCode = error.message.includes('HTTP error!') ? 502 : 500;
        res.status(statusCode).json({ error: error.message || 'Internal server error' });
    }
});

app.get('/posts', async (req, res) => {
    try {
        const { type = 'latest' } = req.query;
        if (!['latest', 'popular'].includes(type)) {
            return res.status(400).json({ error: 'Invalid type parameter. Must be either "latest" or "popular"' });
        }

        await updateAnalytics();
        const posts = postsCache.get(type);

        if (!posts || posts.length === 0) {
            return res.status(404).json({ error: 'No posts available' });
        }

        if (type === 'popular') {
            // Get all posts with the maximum comment count
            const maxComments = posts[0]?.commentCount || 0;
            const topPosts = posts.filter(post => post.commentCount === maxComments);
            res.json({ posts: topPosts });
        } else {
            // Get latest 5 posts
            res.json({ posts: posts.slice(0, 5) });
        }
    } catch (error) {
        console.error('Error in /posts endpoint:', error);
        const statusCode = error.message.includes('HTTP error!') ? 502 : 500;
        res.status(statusCode).json({ error: error.message || 'Internal server error' });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something broke!' });
});

const startServer = async (port = PORT) => {
    try {
        const server = app.listen(port, () => {
            console.log(`Server is running on port ${port}`);
        });

        server.on('error', (error) => {
            if (error.code === 'EADDRINUSE') {
                console.log(`Port ${port} is busy, trying port ${port + 1}...`);
                server.close();
                startServer(port + 1);
            } else {
                console.error('Failed to start server:', error);
                process.exit(1);
            }
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

startServer();
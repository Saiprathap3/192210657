# Thunder Client Testing Guide for Social Media Analytics API

## Base URL Configuration
The API is running locally on port 3000 by default.
Base URL: `http://localhost:3000`

## Available Endpoints

### 1. Health Check Endpoint
- **Method**: GET
- **URL**: `/health`
- **Expected Response**:
  ```json
  {
    "status": "ok",
    "timestamp": "2023-XX-XX..." // ISO timestamp
  }
  ```
- **Status Code**: 200 OK

### 2. Users Endpoint (Top 5 Users by Comment Count)
- **Method**: GET
- **URL**: `/users`
- **Expected Success Response**:
  ```json
  {
    "users": [
      {
        "userId": "string",
        "name": "string",
        "commentCount": number
      }
    ]
  }
  ```
- **Status Codes**:
  - 200: Success
  - 404: No user data available
  - 502: Upstream server error
  - 500: Internal server error

### 3. Posts Endpoint
- **Method**: GET
- **URL**: `/posts`
- **Query Parameters**:
  - `type`: (optional) Either "latest" or "popular" (defaults to "latest")
- **Example URLs**:
  - Latest posts: `/posts?type=latest`
  - Popular posts: `/posts?type=popular`
- **Expected Success Response**:
  ```json
  {
    "posts": [
      {
        // Post object with properties
        "commentCount": number
      }
    ]
  }
  ```
- **Status Codes**:
  - 200: Success
  - 400: Invalid type parameter
  - 404: No posts available
  - 502: Upstream server error
  - 500: Internal server error

## Setting Up Thunder Client Tests

1. Install Thunder Client extension in VS Code
2. Create a new Collection named "Social Media Analytics API"
3. Add the following requests:

### Health Check Test
1. Create new request "Health Check"
2. Set Method to GET
3. Set URL to `{{baseUrl}}/health`
4. Expected: 200 OK with status and timestamp

### Users Test
1. Create new request "Get Top Users"
2. Set Method to GET
3. Set URL to `{{baseUrl}}/users`
4. Expected: 200 OK with array of top 5 users

### Posts Tests
1. Create two requests:
   - "Get Latest Posts"
   - "Get Popular Posts"
2. Set Method to GET for both
3. Set URLs:
   - Latest: `{{baseUrl}}/posts?type=latest`
   - Popular: `{{baseUrl}}/posts?type=popular`
4. Expected: 200 OK with array of posts

## Environment Setup
1. Create new Environment in Thunder Client
2. Add variable:
   - Name: `baseUrl`
   - Value: `http://localhost:3000`

## Running Tests
1. Start your server: `npm run dev`
2. Select the environment you created
3. Run individual requests or the entire collection
4. Verify response status codes and body structure